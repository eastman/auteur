get.ancestor.of.node <-
function(node, phy) {
	anc=phy$edge[which(phy$edge[,2]==node),1]
	anc
}

