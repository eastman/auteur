tune.value <-
function(values, jumpsize) {
	ss=sample(values, 1)
	ww=which(values==ss)
	nn=adjustvalue(ss,jumpsize)
	values[ww]=nn
	return(values)
}

