splitrate <-
function(cur.vv, n.desc, n.split, factor=log(2)){
	dev=cur.vv-exp(log(cur.vv)+runif(1, -factor, factor))
	nr.desc=cur.vv+dev/n.desc
	nr.split=cur.vv-dev/n.split
#	print((nr.split*n.split+nr.desc*n.desc)/(n.desc+n.split)-cur.vv)
	return(list(nr.desc=nr.desc, nr.split=nr.split))
}

