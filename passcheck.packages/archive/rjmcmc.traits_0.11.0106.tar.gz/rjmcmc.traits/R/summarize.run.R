summarize.run <-
function(cOK, endparms, cur.model) {
#	endparmsOU = c(nRateProp, nRootProp, nAlphaProp, nTcatProp, nThetaProp)

	if(cur.model=="BM") {
		names(endparms)<-names(cOK)<-c("rates", "rate.swap", "rate.catg", "root")
	} else {
		names(endparms)<-names(cOK)<-c("rate", "root", "alpha", "regimes", "theta")
	}
	names(endparms)=paste("pr.",names(endparms),sep="")
	names(cOK)=paste("ok.",names(cOK),sep="")
	cat("\n")
	if(cur.model=="BM") {
		print(endparms[paste("pr.", c("rates", "rate.swap", "rate.catg", "root"),sep="")])
		print(cOK[paste("ok.", c("rates", "rate.swap", "rate.catg", "root"),sep="")])
	} else {
		print(endparms[paste("pr.", c("rate", "root", "alpha", "regimes", "theta"),sep="")])
		print(cOK[paste("ok.", c("rate", "root", "alpha", "regimes", "theta"),sep="")])
	}
}

