randomization.test <-
function(obs=obs, exp=exp, iter=10000, verbose=FALSE, two.tailed=FALSE){
	if(verbose && length(obs)<iter) warning("iterations exceeds observed data")
	if(verbose) warning(paste("p-value roughly approximated for ",length(exp), " values\n",sep=""))
	
	O=sample(obs, iter, replace=TRUE)
	E=sample(exp, iter, replace=TRUE)
	
	result=list(c(O-E))
	p=array(NA, iter)
	
	for(i in 1:length(result[[1]])){
		if(result[[1]][i]>0) {
			p[i]=1
		} else {
			if(result[[1]][i]==0) {
				p[i]=sample(c(0,1),1)
			} else {
				p[i]=0
			}
		}
	}
	
	p.g=round(1-(sum(p)/iter), digits=nchar(iter))
	p.l=1-p.g
	
	if(verbose) res=list(c(O-E),greater=p.g,lesser=p.l) else res=list(greater=p.g,lesser=p.l)
	if(two.tailed) res=min(c(p.g,p.l))*2 else res=res
	return(res)
}

