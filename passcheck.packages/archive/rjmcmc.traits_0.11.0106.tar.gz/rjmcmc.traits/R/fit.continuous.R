fit.continuous <-
function(phy, dat){
		n=Ntip(phy)
		ic=try(pic(dat,phy),silent=TRUE)
		if(!inherits(ic, "try-error")) {
			r=mean(ic^2)*((n-1)/n)
			return(r)
		} else {
			return(fitContinuous(phy,dat)$Trait1$beta)
		}
}

