is.root <-
function(node,phy) {
	if(node==phy$edge[1,1]) return(TRUE) else return(FALSE)
}

