new.bm.lik.fn <-
function(rates, root, orig.dat, vcv) { # from LJ HARMON	
# mod 12.02.2010 JM Eastman: using determinant()$modulus rather than det() to stay in log-space
	y=orig.dat
	
	b <- vcv
	w <- rep(root, nrow(b))
	num <- -t(y-w)%*%solve(b)%*%(y-w)/2
	den <- 0.5*(length(y)*log(2*pi) + as.numeric(determinant(b)$modulus))
	list(
		 root=root,
		 lnL = (num-den)[1,1]
		 )	
}

