prepare.data <-
function(phy, data) {
	td <- treedata(phy, data, sort = TRUE)	
	return(list(ape.tre=td$phy, orig.dat=td$data[,1]))
}

