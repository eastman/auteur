pool.rjmcmcsamples <-
function(base.dirs, lab=""){
	outdir=paste(lab,"combined.rjMCMC",sep=".")
	if(!file.exists(outdir)) dir.create(outdir)
	rates=intercalate.samples(lapply(base.dirs, function(x) {y=read.table(paste(x, dir(x, pattern="rates.txt"), sep="/")); names(y)=as.numeric(y[1,]); return(y[-1,])}))
	rates=rbind(names(rates), rates)
	write.table(rates, paste(outdir, "rates.txt", sep="/"), row.names=FALSE, col.names=FALSE, quote=FALSE)
	
	shifts=intercalate.samples(lapply(base.dirs, function(x) {y=read.table(paste(x, dir(x, pattern="rate.shifts.txt"), sep="/")); names(y)=as.numeric(y[1,]); return(y[-1,])}))
	shifts=rbind(names(shifts), shifts)
	write.table(shifts, paste(outdir, "rate.shifts.txt", sep="/"), row.names=FALSE, col.names=FALSE, quote=FALSE)

	write.table(intercalate.samples(lapply(base.dirs, function(x) {y=read.table(paste(x, dir(x, pattern="rjTrait.log"), sep="/"), header=TRUE); return(y)})), paste(outdir, "rjTrait.log", sep="/"), quote=FALSE, row.names=FALSE)
	write.table(intercalate.samples(lapply(base.dirs, function(x) {y=read.table(paste(x, dir(x, pattern="summary.txt"), sep="/"), header=TRUE); return(y)})), paste(outdir, "summary.txt", sep="/"), quote=FALSE, row.names=FALSE)
}

