#plotting function for comparing posterior densities of evolutionary process 'shifts' along a phylogeny
#author: JM EASTMAN 2010

shifts.plot <-
function(phy, base.dir, burnin=0, level=0.03, internal.only=FALSE, paint.branches=TRUE, legend=TRUE, pdf=TRUE, verbose=TRUE, lab="OUT", ...) {
	nullphy=phy
	nullphy$tip.label[]=""
	color.length=17
	require(ape)
	oldwd=getwd()
	setwd(base.dir)
	files=dir()
	if(any(grep("optima", files))) optima=TRUE else optima=FALSE
	if(optima) {
		shifts.file=files[grep("optima.shifts.txt", files)]
		estimates.file=files[grep("optima.txt", files)]
	} else {
		shifts.file=files[grep("rate.shifts.txt", files)]
		estimates.file=files[grep("rates.txt", files)]
	}
	if(pdf | verbose) {
		out.base=paste(lab, paste("bi", burnin, sep=""), paste("fq", level, sep=""), sep=".")
		outdir=paste("./results")
		if(!file.exists(outdir)) dir.create(outdir)
	}
	cat("READING shifts...\n")
	results=read.table(shifts.file)
	names(results)=as.numeric(results[1,])
	burnin=ceiling(burnin*nrow(results))
	results=results[-c(1:(burnin+1)),]
	if(!all(names(results)%in%phy$edge[,2])) stop("Cannot process results: check that tree matches posterior summaries")
	hits.tmp<-shifts<-apply(results,1,sum)
	hits=length(hits.tmp[hits.tmp>0])
	aa.tmp=apply(results, 2, function(x) sum(x))
	aa.tmp=aa.tmp/hits
	aa=aa.tmp[aa.tmp>=level]
	aa=aa[order(aa, decreasing=TRUE)]
	aa.nodes=aa[which(as.numeric(names(aa))>Ntip(phy))]
	aa.tips=aa[which(as.numeric(names(aa))<=Ntip(phy))]
	aa=aa.nodes
	nodes=as.numeric(names(aa))
	nodes=nodes[nodes>Ntip(phy)]
	desc=lapply(nodes, function(x) {
				foo=get.descendants.of.node(x,phy)
				if(length(foo)) return(phy$tip.label[foo[foo<=Ntip(phy)]]) else return(NULL)
				}
				)
	cat("READING estimates...\n")
	ests=read.table(estimates.file)
	names(ests)=ests[1,]
	ests=ests[-c(1:(burnin+1)),]
	average.ests.tmp=apply(ests,2,mean)
	average.ests=average.ests.tmp-median(average.ests.tmp)
	if(paint.branches) {
		colors.branches.tmp=branchcol.plot(phy, ests, plot=FALSE, color.length=17)
		colors.branches=colors.branches.tmp$col
	} else {
		colors.branches=1
	}
	ccx=diverge_hcl(color.length, power = 0.5)
	c.seq=round(seq(-1,1,length=color.length),digits=1)
	
	if(length(nodes)) {
		require(colorspace)
		cols=sapply(nodes, function(x) {
					a=get.ancestor.of.node(x, phy)
					comp=ests[,which(names(ests)==a)]
					this=ests[,which(names(ests)==x)]
					if(!length(comp)) { # dealing with first descendant of root
					d=get.desc.of.node(a, phy)
					d=d[which(d!=x)]
					d.shifts=results[, which(names(results)==d)]
					comp=ests[,which(names(ests)==d)]
					x.res=sapply(1:length(d.shifts), function(y) {
								 if(d.shifts[y]==0) {
								 zz=this[y]-comp[y]
								 if(zz>0) {
								 return(1) 
								 } else {
								 if(zz<0) return(-1) else return(0)
								 }
								 } else {
								 return(0)
								 }
								 }
								 )
					x.res=mean(x.res[x.res!=0])
					if(is.na(x.res)) x.res=0
					} else {
					yy=this-comp
					zz=yy
					zz[yy>0]=1
					zz[yy<0]=-1
					zz[yy==0]=0
					x.res=mean(zz[zz!=0])
					if(is.na(x.res)) x.res=0
					}
					return(x.res)
					}
					)
		colors.nodes=ccx[match(round(cols,1),c.seq)]
		names(colors.nodes)=nodes
		colors.nodes=colors.nodes[which(as.numeric(names(colors.nodes))>Ntip(phy))]
	} else {
		colors.nodes=NULL
		cols=NULL
	}
	
	if(length(aa.tips) & !internal.only) {
		tt<-tt.cex<-rep(0,Ntip(phy))
		tt[as.numeric(names(aa.tips))]=1
		tt.cex[as.numeric(names(aa.tips))]=aa.tips
		
		tt.col=sapply(names(aa.tips), function(x) {
					  a=get.ancestor.of.node(x, phy)
					  comp=ests[,which(names(ests)==a)]
					  this=ests[,which(names(ests)==x)]
					  if(!length(comp)) { # dealing with first descendant of root
					  d=get.desc.of.node(a, phy)
					  d=d[which(d!=x)]
					  d.shifts=results[, which(names(results)==d)]
					  comp=ests[,which(names(ests)==d)]
					  x.res=sapply(1:length(d.shifts), function(y) {
								   if(d.shifts[y]==0) {
								   zz=this[y]-comp[y]
								   if(zz>0) {
								   return(1) 
								   } else {
								   if(zz<0) return(-1) else return(0)
								   }
								   } else {
								   return(0)
								   }
								   }
								   )
					  x.res=mean(x.res[x.res!=0])
					  } else {
					  yy=this-comp
					  zz=yy
					  zz[yy>0]=1
					  zz[yy<0]=-1
					  zz[yy==0]=0
					  x.res=mean(zz[zz!=0])
					  }
					  return(x.res)
					  }
					  )
		tt.ccx=diverge_hcl(color.length, power = 0.5)
		tt.c.seq=round(seq(-1,1,by=0.1),digits=1)
		tt.colors.nodes=tt.ccx[match(round(tt.col,1),tt.c.seq)]
		names(tt.colors.nodes)=as.numeric(names(aa.tips))
		colors.tips.tmp=tt.colors.nodes[order(as.numeric(names(tt.colors.nodes)))]
		colors.tips=rep(NA, Ntip(phy))
		colors.tips[as.numeric(names(colors.tips.tmp))]=colors.tips.tmp
		tip.names=as.list(phy$tip.label[as.numeric(names(aa.tips))])
		names(tip.names)=paste("node",names(aa.tips),sep=".")
		names(colors.tips)=1:Ntip(phy)
	}	else {
		tt.cex=NULL
		tt.col=NULL
		tip.names=NULL
		colors.tips=NULL
		tt=rep(0,Ntip(phy))
	}
	
	## PLOTTING OF TREE
	CEX=max(c(0.05, (2+-0.36*log(Ntip(phy))) ))	
	if(legend) {
		def.par <- par(no.readonly = TRUE) 
		on.exit(par(def.par))
		layout(matrix(c(1,2,1,3,1,4), 3, 2, byrow=TRUE), widths=c(20,5), respect=FALSE)
	}
	if(pdf) pdf(file=paste(outdir, paste(out.base,"pdf",sep="."),sep="/"))
	plot(phy, cex=CEX, lwd=0.4, edge.color=colors.branches, show.tip.label=TRUE, label.offset=strwidth(par("pch"),cex=1.25), no.margin=TRUE, ...)
	NN=phy$edge[,2]
	ll<-cc<-rr<-rep(0,length(NN))
	if(length(nodes)) {
		ll[NN%in%nodes]=1
		cc[match(names(aa), NN)]=aa
		rr[match(names(colors.nodes), NN)]=colors.nodes
		names(cols)=names(aa)
		names(desc)=paste("node",nodes,sep=".")
	}
	if(length(aa.tips)) {
		tips=as.numeric(names(aa.tips))
		ll[NN%in%tips]=1
		cc[match(names(aa.tips), NN)]=aa.tips
		rr[match(names(colors.tips.tmp), NN)]=colors.tips.tmp
	}
	edgelabels.rj(text=NULL, pch=ifelse(ll==1, 21, NA), cex=4*cc, col=rr, bg=rr, lwd=0.5)
	
	if(legend) {
		legend.seq=seq(1,color.length,by=2)
		point.seq=rev(seq(0.2,0.8,length=length(legend.seq)))
		
		# shift direction
		plot(rep(-0.5, length(point.seq)), point.seq, xlim=c(-1,2), ylim=c(0,1), cex=2, pch=21, col = "darkgray", bg = rev(ccx[legend.seq]), bty="n", xaxt="n", yaxt="n")
		mtext("shift direction",side=3,line=-3,cex=0.75)
		text(rep(1, length(point.seq)), point.seq, adj=1, labels=sprintf("%9.2f", rev(c.seq[legend.seq])))

		# posterior rates
		if(any(colors.branches!=1)) {
			cbt=colors.branches.tmp$legend.seq
			cbt=100*colors.branches.tmp$legend.seq
			lchars=sapply(cbt, floor)
			if(all(lchars>0)) {
				ldec=1
			} else if(all(lchars==0)) {
				ldec=min(5, max(nchar(range(cbt))))
			} else {
				ldec=2
			}
				
			lnchar=max(nchar(lchars))+ldec
			plot(rep(-0.5, length(point.seq)), point.seq, xlim=c(-1,2), ylim=c(0,1), cex=2, pch=22, col = "darkgray", bg = rev(colors.branches.tmp$legend.col[legend.seq]), bty="n", xaxt="n", yaxt="n")
			mtext("posterior rates",side=3,line=-3,cex=0.75)
			text(rep(1, length(point.seq)), point.seq, adj=1, labels=sprintf(paste("%",max(10,lnchar),".",ldec,"f",sep=""), cbt[legend.seq]))

		}

		# posterior probabilities of shift
		plot(rep(-0.5, length(point.seq)), point.seq, xlim=c(-1,2), ylim=c(0,1), cex=4*(seq(1, 0, length=9)), pch=21, col = add.transparency("darkgray",0.8), bg = add.transparency("white",0.8), bty="n", xaxt="n", yaxt="n")
		mtext("shift probability",side=3,line=-3,cex=0.75)
		text(rep(1, length(point.seq)), point.seq, adj=1, labels=sprintf("%10.3f", seq(1, 0, length=9)))
		
		# reset plotting device
		invisible()
	}
	if(pdf) dev.off()
	
	# GENERATE TABULAR OUTPUT of RESULTS
	if(verbose) {
		summary.table=c(hits/nrow(results), mean(shifts), median(shifts))
		names(summary.table)=c("shift.prob", "mean.shift","median.shifts")
		write.table(summary.table, file=paste(outdir, paste(out.base, "run.summary.txt", sep="."), sep="/"), quote=FALSE, col.names=FALSE)
		if(length(nodes)) {
			for(nn in 1:length(nodes)) {
				write.table(c(nodes[nn], desc[[nn]]), file=paste(outdir, paste(out.base, "shift.descendants.txt", sep="."), sep="/"), append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
			}
		}
		if(length(aa.tips)) {
			for(nn in 1:length(aa.tips)) {
				write.table(c(as.numeric(names(aa.tips)[nn]), tip.names[[nn]]), file=paste(outdir, paste(out.base, "shift.descendants.txt", sep="."), sep="/"), append=TRUE, quote=FALSE, row.names=FALSE, col.names=FALSE)
			}
		}
		allres=data.frame(matrix(NA, nrow=nrow(phy$edge), ncol=3))
		if(length(aa)) {
			x=as.numeric(names(aa))
			nodres=merge(as.data.frame(aa),as.data.frame(cols),by=0)
			allres[nodres[,1],]=nodres
		}
		if(length(aa.tips)) {
			x=as.numeric(names(aa.tips))
			tipres=merge(as.data.frame(aa.tips), as.data.frame(tt.col),by=0)
			allres[tipres[,1],]=tipres
		}
		allres=allres[!apply(allres, 1, function(x)any(is.na(x))),]
		allres=allres[order(allres[,2], decreasing=TRUE),]
		if(nrow(allres)>0) {
			allres=data.frame(allres)
			names(allres)=c("node", "conditional.shift.probability", "relative.shift.direction")
			write.table(allres, file=paste(outdir, paste(out.base, "estimates.summary.txt", sep="."), sep="/"), quote=FALSE, row.names=FALSE)
		}
	}
	setwd(oldwd)
	
	if(!optima) {
		return(list(desc=desc, tips=tip.names, shift.prob=hits/nrow(results), mean.shifts=mean(shifts), median.shifts=median(shifts), nodeshift.prop=aa, nodeshift.direction=cols, tipshift.prop=aa.tips, tipshift.direction=tt.col, mean.rates=average.ests.tmp, mean.shifts=aa.tmp/nrow(results)))
	} else {
		return(list(desc=desc, tips=tip.names, shift.prob=hits/nrow(results), mean.shifts=mean(shifts), median.shifts=median(shifts), nodeshift.prop=aa, nodeshift.direction=cols, tipshift.prop=aa.tips, tipshift.direction=tt.col, mean.optima=average.ests.tmp, mean.shifts=aa.tmp/nrow(results)))
	}
}

