#logging utility used by rjmcmc
#author: JM EASTMAN 2010

generate.error.message <-
function(i, mod.cur, mod.new, lnL, lnPrior, lnHastings, errorLog) {
	if(!file.exists(file=errorLog)) write(paste("gen", "curr.lnL", "new.lnL", "lnL", "lnPrior", "lnHastings", sep="\t"), file=errorLog)

	write(paste(i, sprintf("%.3f", mod.cur$lnL), sprintf("%.3f", mod.new$lnL), sprintf("%.3f", lnL), sprintf("%.3f", lnPrior), sprintf("%.3f", lnHastings), sep="\t"), file=errorLog, append=TRUE)
	
}

