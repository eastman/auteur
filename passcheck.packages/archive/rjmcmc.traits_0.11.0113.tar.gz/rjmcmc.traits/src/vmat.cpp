#include <Rcpp.h>
#include <vector>

/* 
 * FUNCTIONS TO GENERATE VARIANCE-COVARIANCE MATRIX from an S3 'phylo' object from the R-package ape (Paradis E, J Claude, and K Strimmer 2004 [BIOINFORMATICS 20:289-290])
 * author: Jonathan M Eastman 01.11.2011
 */


/* INTERNAL C++ */
void gatherdescendants(int const &node,
					   int const &root,
					   int const &endofclade,
					   std::vector<int> &DESC,
					   RcppVector<int> const &anc, 
					   RcppVector<int> const &des)
{
	/* 
	 * node: current internal node
	 * root: most internal node
	 * endofclade: number of rows in the phylogenetic edge matrix (of the 'phylo' object)
	 * DESC: vector in which to store all descendants of node (by node label)
	 * anc: first column of 'phylo' edge matrix (e.g., phy$edge[,1])
	 * des: second column of 'phylo' edge matrix (e.g., phy$edge[,2])
	 */
	
	int i;

	for(i=0; i<endofclade; i++) {
		if(anc(i) == node)
		{
			DESC.push_back(des(i));
			if(des(i)>root)
			{
				gatherdescendants(des(i), root, endofclade, DESC, anc, des);
			}
		}
	}
}
	
					   
/* INTERNAL C++ */
void descend_vcv(int const &node,
				 double const &edge,
				 int const &root,
				 int const &endofclade,
				 RcppVector<int> const &anc, 
				 RcppVector<int> const &des, 
				 RcppMatrix<double> &vcv,
				 std::vector<int> &DESC)
{
	/* 
	 * node: internal node of which descendants are recorded
	 * edge: length to add to covariances of all descendants where 'node' is internal
	 * root: node to initiate vcv update
	 * endofclade: rows in the phylogenetic edge matrix (of the 'phylo' object)
	 * anc: first column of phylo edge matrix (e.g., phy$edge[,1]
	 * des: second column of phylo edge matrix (e.g., phy$edge[,2]
	 * vcv: the current variance-covariance matrix
	 * DESC: an empty vector in which to store all descendants of node
	 */
	
	int i,a,b,j;
	std::vector<int> TIPS;
	
	gatherdescendants(node, root, endofclade, DESC, anc, des);
	
	/* find tips within the set of descendants of 'node' */
	for(i=0; i<DESC.size(); i++) {
		if(DESC.at(i)<root)
		{
			TIPS.push_back(DESC.at(i));
		}
	}
	
	/* add 'edge' length of 'node' to covariances V[a,b] where a and b are tips descended from 'node' and a!=b [OFFDIAGONAL ELEMENTS in V] */
	for(a=0; a<TIPS.size(); a++) {
		for(b=a; b<TIPS.size(); b++) {
			if(a!=b)
			{
				vcv( TIPS.at(a)-1, TIPS.at(b)-1 ) = vcv( TIPS.at(b)-1, TIPS.at(a)-1 ) += edge;
			}
		}
	}
	
	/* add 'edge' length of 'node' to variances of V[a,b] where a and b are tips descended from 'node' and a==b [DIAGONAL ELEMENTS in V]*/ 
	for(j=0; j<TIPS.size(); j++) {
		vcv( TIPS.at(j)-1, TIPS.at(j)-1 ) += edge;
	}
	
	TIPS.clear();
}


/* INTERNAL C++ */
void vcv_internal (int const &maxnode,
				   int const &root,
				   int const &endofclade,
				   RcppVector<int> const &anc, 
				   RcppVector<int> const &des, 
				   RcppVector<double> const &edges, 
				   RcppMatrix<double> &vcv)
{
	/* 
	 * maxnode: largest internal node
	 * root: most internal node
	 * endofclade: number of rows in the phylogenetic edge matrix (of the 'phylo' object)
	 * anc: first column of phylo edge matrix (e.g., phy$edge[,1]
	 * des: second column of phylo edge matrix (e.g., phy$edge[,2]
	 * edges: sorted branch lengths (by node label), including the root (ntips+1)
	 * vcv: the current state of the variance-covariance matrix 
	 */
	
	int n,i,a,b,j;
	std::vector<int> DESC;	
	
	
	/* cycle over internal nodes within the tree; tree stem does not contribute to VCV so is skipped */
	for(n=root+1; n<=maxnode; n++) {
		
		/* find descendants of n; add edge length of n to variances for tips and covariances among tips */	
		descend_vcv(n, edges(n-1), root, endofclade, anc, des, vcv, DESC);
					
		DESC.clear();
	}
	
	/* add leaves to lengths in V[n,n] where n is a tip [DIAGONAL ELEMENTS in V]*/
	for(n=1; n<root; n++) {
		vcv( n-1, n-1 ) += edges(n-1);
	}
}

/* C++ | R INTERFACE */
RcppExport SEXP vmat (SEXP tree, SEXP ANC, SEXP DES, SEXP EDGES, SEXP VCV) 
{
	/* 
	 * tree: a list of elements 
		* ROOT: most internal node
		* MAXNODE: least internal internal node (and largest valued in edge matrix)
		* ENDOFCLADE: rows in edge matrix
	 * ANC: first column of 'phylo' edge matrix (e.g., phy$edge[,1])
	 * DES: second column of 'phylo' edge matrix (e.g., phy$edge[,2])
	 * EDGES: edge lengths, sorted by node label and including the root (at position Ntip(phy)+1)
	 * VCV: the current state of the variance-covariance matrix 
	 */
	
	SEXP rl=R_NilValue;
	char *exceptionMesg=NULL;
	
	try {
		int i,j,k,sumfrom;
		int* a;
		
		a=0;
		
		/* call in parameters associated with 'phylo' object */
		RcppParams phylo(tree);

		int root = phylo.getIntValue("ROOT");
		int	maxnode = phylo.getIntValue("MAXNODE");
		int	endofclade = phylo.getIntValue("ENDOFCLADE");
		RcppVector<int> anc(ANC);
		RcppVector<int> des(DES);
		RcppVector<double> edges(EDGES);
		RcppMatrix<double> V(VCV);
		
		/* call to primary function that updates VCV matrix */
		vcv_internal(maxnode, root, endofclade, anc, des, edges, V);
		
		/* PREPARE OUTPUT FOR R */
		RcppResultSet rs;
		rs.add("VCV",  V);
		rl = rs.getReturnList();


	} catch(std::exception& ex) {
		exceptionMesg = copyMessageToR(ex.what());
    } catch(...) {
		exceptionMesg = copyMessageToR("unknown reason");
    }
    
    if(exceptionMesg != NULL)
		Rf_error(exceptionMesg);
	
    return rl;	
}
