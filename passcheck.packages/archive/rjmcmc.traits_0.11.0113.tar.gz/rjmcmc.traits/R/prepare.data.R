#general phylogentic utility wrapping geiger:::treedata for checking data consistency
#author: JM EASTMAN 2010

prepare.data <-
function(phy, data) {
	td <- treedata(phy, data, sort = TRUE)	
	return(list(ape.tre=td$phy, orig.dat=td$data[,1]))
}

