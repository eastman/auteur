sortedges=function(phy) {
	c(0, phy$edge.length)[sort(c(Ntip(phy)+1, phy$edge[,2]),index=TRUE)$ix]
}