vmat <- function(phy, edges=NULL){
	recomp=FALSE
	if(length(phy$tip.label)>2) if(attr(phy,"order")!="cladewise") {phy=reorder(phy); recomp=TRUE}
	if(is.null(edges) | recomp) edges=sortedges(phy)
	
	n=Ntip(phy)
	nn=Nnode(phy)+n
	out <- .Call("vmat", tree=list(
									   ROOT = as.integer(n+1),
									   MAXNODE = as.integer(max(phy$edge[,1])),
									   ENDOFCLADE = as.integer(dim(phy$edge)[1])),
				 
									ANC = phy$edge[,1],
									DES = phy$edge[,2],
									EDGES = edges,
									VCV = matrix(0, nn, nn),
									PACKAGE = "rjmcmc.traits")
	v=out$VCV[1:n,1:n]
	rownames(v)<-colnames(v)<-phy$tip.label
	return(v)
} 

		
