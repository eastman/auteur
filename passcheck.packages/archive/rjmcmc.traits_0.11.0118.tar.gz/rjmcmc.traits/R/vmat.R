vmat <- function(phy){
	n=Ntip(phy)
	nn=Nnode(phy)+n
	out <- .Call("vmat", tree=list(
									   ROOT = as.integer(n+1),
									   MAXNODE = as.integer(max(phy$edge[,1])),
									   ENDOFCLADE = as.integer(dim(phy$edge)[1])),
				 
									ANC = phy$edge[,1],
									DES = phy$edge[,2],
									EDGES = c(phy$edge.length,0),
									VCV = matrix(0, n, n),
									PACKAGE = "rjmcmc.traits")
	v=out$VCV
	rownames(v)<-colnames(v)<-phy$tip.label
	return(v)
} 

		
