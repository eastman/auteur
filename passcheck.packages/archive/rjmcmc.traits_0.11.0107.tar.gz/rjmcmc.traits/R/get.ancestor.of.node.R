#general phylogenetic utility for returning first ancestor (as a numeric referent) of the supplied node 
#author: JM EASTMAN 2010

get.ancestor.of.node <-
function(node, phy) {
	anc=phy$edge[which(phy$edge[,2]==node),1]
	anc
}

