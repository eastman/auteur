
adjustjump=function(jump.table, jVCV, k, r, add=FALSE, drop=FALSE, swap=FALSE, phy, node.des){
	orig=jump.table
	jj=jVCV
	if(add==TRUE){
		
		adjustedjump.newloc=propose.loc(phy,, k, Inf)
		jump.table=rbind(jump.table, unlist(adjustedjump.newloc))
		jVCV=updateJvcv(jVCV, from=NULL, to=adjustedjump.newloc$node, node.des)
		ajl=NULL
		todo="add"
	} else if(drop==TRUE | swap==TRUE) {

		possible.locs=seq(2,nrow(jump.table))
		adjustedjump.index<-aji<-possible.locs[ceiling(runif(1)*length(possible.locs))]
		adjustedjump.loc<-ajl<-as.list(jump.table[adjustedjump.index,])
		
		if(drop==TRUE) {
			
			jump.table=jump.table[-adjustedjump.index,]
			jVCV=updateJvcv(jVCV, from=adjustedjump.loc$node, to=NULL, node.des)
			todo="drop"
		} else if(swap==TRUE){
			
			adjustedjump.newloc<-ajnl<-propose.loc(phy, adjustedjump.loc, k, r)
			jump.table[adjustedjump.index,]=unlist(adjustedjump.newloc)			
			if((from<-adjustedjump.loc$node) != (to<-adjustedjump.newloc$node)) {
				jVCV=updateJvcv(jVCV, from=from, to=to, node.des)
			} else {
				jVCV=jVCV
			}
			todo="swap"
		} else {
			stop("Error encountered.")
		}
	} else {
		stop("Must 'add', 'drop', or 'swap' jumps.")
	}

	return(list(jump.table=jump.table, jVCV=jVCV))
}

updateJvcv=function(jVCV, from=NULL, to=NULL, node.des){
# from: a node for which a jump has been removed
# to: a node for which a jump has been added
	if(!is.null(from)) {
		ff=node.des[[which(names(node.des)==from)]]
		jVCV[ff,ff]=jVCV[ff,ff]-1
	}
	
	if(!is.null(to)){
		tt=node.des[[which(names(node.des)==to)]]
#		print(list(to,tt))
		jVCV[tt,tt]=jVCV[tt,tt]+1
	}
	jVCV
}

updateLvcv=function(Tvcv, Lvcv, sigsqB, sigsqJ){
	return(sigsqB*Tvcv+sigsqJ*Lvcv)
}


#### FUNCTIONS BELOW FROM LIAM REVELL evol.rate.mcmc.R v0.2 ###

match.all<-function(s,v){
	result<-vector(mode="numeric")
	j=1
	for(i in 1:length(v)){
		if(s==v[i]){
			result[j]=i
			j=j+1
		}
	}
	if(j==1) result<-NA
	return(result)
}

random.node<-function(phy){
	# sum edges cumulatively
	cum.edge<-vector(mode="numeric"); index<-vector(mode="numeric")
	for(i in 1:length(phy$edge.length)){
		if(i==1) cum.edge[i]<-phy$edge.length[1]
		else cum.edge[i]<-cum.edge[i-1]+phy$edge.length[i]
		index[i]<-phy$edge[i,2]
	}
	# pick random position
	pos<-runif(1)*cum.edge[length(phy$edge.length)]
	edge<-1
	while(pos>cum.edge[edge]) edge<-edge+1
	return (index[edge])
}


propose.loc<-function(phy,loc,k,r){	
	# k: 0.2*mean(diag(VCV)) -- defined from con$kloc
	# r:  variate [0,1] -- defined from con$rand.shift
	# loc: list with elements 'node' and 'bp' 
	loc.prime<-list()
	if(runif(1)>r){
		loc.prime<-tree.step(phy,loc$node,loc$bp,step=k*rexp(n=1,rate=1)) # update node & bp by random walk
	} else {
		loc.prime$node<-random.node(phy) # pick random branch
		loc.prime$bp<-runif(1)*phy$edge.length[match(loc.prime$node,phy$edge[,2])]
	}
	return(loc.prime)
}


tree.step<-function(phy,node,bp,step,up=NA){
	# bp: branch position
	# step: step size along branch
	# up: binary (whether to move up or down)
	if(step<0)
		step=-step # if user has given -step, positivize
	if(is.na(up))
		up=(runif(1)>0.5) # if up/down is not assigned, we must be in the middle of a branch
	# decide to go up (1) or down (0) with equal probability
	if(up){
		# pick a new position along the branch (or go to the end)
		new.bp<-min(bp+step,phy$edge.length[match(node,phy$edge[,2])])
		# adjust step length to remain step
		step=step-(new.bp-bp)
		# check to see if we are done
		if(step<1e-6){
			return(list(node=node,bp=new.bp))
		} else {
			# we are going up, so get the daughters
			daughters<-phy$edge[match.all(node,phy$edge[,1]),2]
			# pick a random daughter
			new.node<-daughters[ceiling(runif(1)*length(daughters))]
			if(is.na(new.node)){
				location<-tree.step(phy,node,phy$edge.length[match(node,phy$edge[,2])],step,up=FALSE) # we are at a tip
			} else {
				location<-tree.step(phy,new.node,0,step,up=TRUE)
			}
		}
	} else {
		# pick a new position along the branch (or go to the start)
		new.bp<-max(bp-step,0)
		# adjust step length
		step=step-(bp-new.bp)
		# check to see if we are done
		if(step<1e-6){
			return(list(node=node,bp=new.bp))
		} else {
			# we are going down so find out who the parent is
			parent<-phy$edge[match(node,phy$edge[,2]),][1]
			# find the other daughter(s)				
			daughters<-phy$edge[match.all(parent,phy$edge[,1]),2]
			# do not use parent if root
			if(parent==(length(phy$tip.label)+1)){
				parent=NULL # if at the base of the tree
			}
			# create a vector of the possible nodes: the parent, and sister(s)				
			possible.nodes<-c(parent,daughters[-match(node,daughters)])
			# now pick randomly from available nodes
			new.node<-possible.nodes[ceiling(runif(1)*length(possible.nodes))]
			# if parent
			if(is.null(parent)==FALSE&&new.node==parent){
				location<-tree.step(phy,new.node,phy$edge.length[match(new.node,phy$edge[,2])],step,up=FALSE)
			} else {
				location<-tree.step(phy,new.node,0,step,up=TRUE)
			}
		}
	}
}

