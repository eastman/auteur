#logging utility used by rjmcmc
#author: JM EASTMAN 2010

parlogger <- function(phy, init=FALSE, primary.parameter, parameters, parmBase, runLog, end=FALSE) {
	parlogs=paste(parmBase, paste(c("shifts",primary.parameter), "txt", sep="."), sep="")
	if(end==TRUE) {
		sapply(1:length(parlogs), function(x) write.table("\n", parlogs[x], quote=FALSE, col.names=FALSE, row.names=FALSE, append=TRUE))
		return()
	}
	parameters->parms
	parnames=names(parms)
	ii=match(c("gen"),parnames)
	general=match(c("lnL","lnL.p","lnL.h"),parnames)
	delta=match("delta",parnames)
	target=match(primary.parameter, parnames)
	accessory=which(parnames==parnames[-c(ii,delta,target,general)])
	
	if(init) {
		sapply(parlogs[1:length(parlogs)], function(x) write.table("", file=x, quote=FALSE, col.names=FALSE, row.names=FALSE))
		write.table(paste(parnames[ii], "min", "max", "mean", primary.parameter, paste(parnames[accessory],collapse="\t"), paste(parnames[general],collapse="\t"), sep="\t"), file=runLog, quote=FALSE, col.names=FALSE, row.names=FALSE)		
	} else {
		pp=parms[[target]]
		dd=parms[[delta]]
		K=sum(dd)+1
		range.p=range(pp)
		mean.p=mean(pp)
		
		msg<-paste(parms[[ii]], sprintf("%.3f", range.p[1]), sprintf("%.3f", range.p[2]), sprintf("%.3f", mean.p), K, paste(sprintf("%.3f", parms[accessory]),collapse="\t"), paste(sprintf("%.2f", parms[general]),collapse="\t"),sep="\t")
		write(msg, file=runLog, append=TRUE)
		
		nodes=phy$edge[,2]
		first.desc=get.desc.of.node(Ntip(phy)+1,phy)
		
		delta.log=unique(c(first.desc, nodes[which(dd==1)]))
		values.log=pp[match(delta.log,nodes)]
		
		out=list(delta.log,values.log)
		
		sapply(1:length(parlogs), function(x) write.table(paste(out[[x]],collapse=" "), parlogs[x], quote=FALSE, col.names=FALSE, row.names=FALSE, append=TRUE))
	}
}


#rjmcmc utility for initiating a proposal width for Markov sampling
#author: JM EASTMAN 2010

calibrate.jumpsize <-
function(phy, dat, nsteps=100, model, jumpsizes=NULL) {
	if(!withinrange(nsteps, 100, 1000)) {
		if(nsteps>1000) nsteps=1000 else nsteps=100
	}
	if(is.null(jumpsizes)) jumpsizes=2^(-2:3)
	if(model=="BM") {
		acceptance.rates=sapply(jumpsizes, function(x) rjmcmc.bm(phy=phy, dat=dat, ngen=nsteps, jumpsize=x, summary=FALSE, fileBase="jumpsize", internal.only=FALSE)$acceptance.rate)
	} else if(model=="OU") {
		while(1){
			acceptance.rates=sapply(jumpsizes, function(x) {
								f=try(rjmcmc.ou(phy=phy, dat=dat, ngen=nsteps, jumpsize=x, summary=FALSE, fileBase="jumpsize", internal.only=FALSE)$acceptance.rate,silent=TRUE)
								if(inherits(f,"try-error")) return(0) else return(f)
								}
								)
			if(any(acceptance.rates!=0))break()
		}
	}
	return(sum(jumpsizes*(acceptance.rates/sum(acceptance.rates))))
}



#utility for converting text files to .rda to compress output from rjmcmc
#author: JM EASTMAN 2011

cleanup.files <-
function(parmBase, model, fileBase, phy, node.des){
	if(model=="BM") {
		parm="rates"
	} else if(model=="OU") {
		parm="optima"
	}
	parms=c(parm,"shifts")
	
# read in raw data
	ps=lapply(parms, function(x) {
			  y=read.delim(paste(parmBase,paste(x,"txt",sep="."),sep="/"),sep="\n",fill=T,as.is=T)
			  y=lapply(y[,1], function(z) as.numeric(strsplit(z," ")[[1]]))
			  return(y)
			  })
	names(ps)=parms
	
# process data into matrix
	fleshout.rates=function(desc.list, nodes, values, ntip){
		x=array(dim=length(desc.list))
		names(values)=nodes
		vv=c(sort(values[names(values)>ntip]),values[names(values)<=ntip])
		nn=as.numeric(names(vv))
		vv=unname(vv)
		for(n in 1:length(nn)){
			x[desc.list[[nn[n]]]]=vv[n]
		}
		x
	}
	
	n<-Ntip(phy)
	dd<-vv<-matrix(0,nrow=length(ps[[1]]), ncol=(maxnode<-nrow(phy$edge)+1))
	match(1:maxnode,c(n+1,phy$edge[,2]))->m
	desc=node.des[m]
	desc=sapply(1:maxnode, function(x) return(unlist(c(x, desc[[x]]))))
	
	for(i in 1:nrow(dd)) {
		s=ps$shifts[[i]]
		d<-dd[i,s]<-1
		v=ps[[parms[which(parms!="shifts")]]][[i]]
		if(sum(d)==1 & length(unique(v))==1) {
			vv[i,]=v[1]
		} else {
			vv[i,]=fleshout.rates(desc, s, v, n)
		}
	}
	
	dd=dd[m,]
	vv=vv[m,]
	dd=data.frame(dd[,-1])
	vv=data.frame(vv[,-1])
	
	names(dd)<-names(vv)<-phy$edge[,2]
	
	posteriorsamples=list(vv,dd)
	names(posteriorsamples)=parms
	save(posteriorsamples, file=paste(parmBase,paste(fileBase,"posteriorsamples","rda",sep="."),sep="/"))
	unlink(paste(parmBase,paste(parms,"txt",sep="."),sep="/"))
}


#general phylogenetic statistical utility for comparing values ('posterior.rates') from posterior densities for two sets of supplied branches ('nodes')
#author: JM EASTMAN 2010

compare.rates <-
function(branches=list(A=c(NULL,NULL),B=c(NULL,NULL)), phy, posterior.values, ...){
	nodes=branches
	rates=posterior.values
	if(is.null(names(nodes))) names(nodes)=c("A","B")
	rates.a=rates[,match(nodes[[1]],names(rates))]
	rates.b=rates[,match(nodes[[2]],names(rates))]
	edges.a=phy$edge.length[match(nodes[[1]],phy$edge[,2])]
	edges.b=phy$edge.length[match(nodes[[2]],phy$edge[,2])]
	weights.a=edges.a/sum(edges.a)
	weights.b=edges.b/sum(edges.b)
	if(length(nodes[[1]])>1) {r.scl.a=apply(rates.a, 1,function(x) sum(x*weights.a))} else {r.scl.a=sapply(rates.a, function(x) sum(x*weights.a))}
	if(length(nodes[[2]])>1) r.scl.b=apply(rates.b, 1,function(x) sum(x*weights.b)) else r.scl.b=sapply(rates.b, function(x) sum(x*weights.b))
	return(list(scl.A=r.scl.a, scl.B=r.scl.b, r.test=randomization.test(r.scl.a, r.scl.b, ...)))	
}

#general phylogenetic utility for rapid computation of the maximum-likelihood estimate of the Brownian motion rate parameter (unless there are polytomies, in which case the function wraps geiger:::fitContinuous)
#author: L REVELL 2010, LJ HARMON 2009, and JM EASTMAN 2010

fit.continuous <-
function(phy, dat){
	n=Ntip(phy)
	ic=try(pic(dat,phy),silent=TRUE)
	if(!inherits(ic, "try-error")) {
		r=mean(ic^2)*((n-1)/n)
		return(r)
	} else {
		return(fitContinuous(phy,dat)$Trait1$beta)
	}
}

#logging utility used by rjmcmc
#author: JM EASTMAN 2010

generate.error.message <-
function(ntip, i, mod.cur, mod.new, lnL, lnPrior, lnHastings, curCats, newCats, errorLog) {
	if(!file.exists(file=errorLog)) write(paste("nodes", "gen", "cur.lnL", "new.lnL", "lnL", "lnPrior", "lnHastings", "cur.catg", "new.catg", sep="\t"), file=errorLog)
	
	write(paste(2*ntip-2, i, sprintf("%.3f", mod.cur$lnL), sprintf("%.3f", mod.new$lnL), sprintf("%.3f", lnL), sprintf("%.3f", lnPrior), sprintf("%.3f", lnHastings), sum(curCats), sum(newCats), sep="\t"),  file=errorLog, append=TRUE)
	
}

#utility for generating a list of indicator variables and values for each branch in a phylogeny, using a random model complexity as a starting point (or by constraining model complexity)
#author: JM EASTMAN 2010

generate.starting.point <-
function(data, phy, node.des, logspace=TRUE, K=FALSE, jumpsize) { 
	nn=length(phy$edge.length)
	ntip=Ntip(phy)
	if(!K) nshifts=rtpois(1,log(ntip),nn) else nshifts=K-1
	if(nshifts!=0) bb=sample(c(rep(1,nshifts),rep(0,nn-nshifts)),replace=FALSE) else bb=rep(0,nn)
	names(bb)=phy$edge[,2]
	shifts=as.numeric(names(bb)[bb==1])
	if(!logspace) {
		init.rate=mean(data)
		min.max=c(adjustvalue(min(data), jumpsize), adjustvalue(max(data), jumpsize))
		values=runif(sum(bb)+1, min=min.max[min.max==min(min.max)], max=min.max[min.max==max(min.max)])
	} else {
		init.rate=fit.continuous(phy,data)
		min.max=c(adjustrate(init.rate, jumpsize), adjustrate(init.rate, jumpsize))
		values=runif(sum(bb)+1, min=min.max[min.max==min(min.max)], max=min.max[min.max==max(min.max)])
	}
	internal.shifts<-tip.shifts<-numeric(0)
	internal.shifts=sort(shifts[shifts>ntip])
	tip.shifts=shifts[shifts<=ntip]
	
	if(length(internal.shifts)==0 & length(tip.shifts)==0) {
		vv=rep(values, nn)
	} else {
		vv=bb
		vv[]=values[length(values)]
		i=0
		if(length(internal.shifts)!=0) {
			for(i in 1:length(internal.shifts)) {
				d=node.des[which(names(node.des)==internal.shifts[i])]
				vv[match(c(internal.shifts[i], unlist(d)), names(vv))]=values[i]
			}
		}
		if(length(tip.shifts)!=0) {
			for(j in 1:length(tip.shifts)) {
				vv[match(tip.shifts[j], names(vv))]=values[j+i]
			}
		}
	}
	return(list(delta=unname(bb), values=unname(vv)))
}

#general utility for combining supplied list of dataframes into a single 'intercalated' sample. E.g., list(as.data.frame(c(AAA)),as.data.frame(c(BBB))) becomes data.frame(c(ABABAB))
#author: JM EASTMAN 2010

intercalate.samples <-
function(list.obj) {
	if(length(list.obj)<2) warning("Nothing to be done... too few objects in list.")
	vv=sapply(list.obj, is.vector)
	if(all(vv)) list.obj=lapply(list.obj, function(x) {y=data.frame(x); names(y)=NULL; return(y)})
	orig.names=names(list.obj[[1]])
	n=length(list.obj)
	R=sapply(list.obj, nrow)
	if(length(unique(R))!=1) {
		minR=nrow(list.obj[[which(R==min(R))]])
		list.obj=lapply(list.obj, function(x) {y=as.data.frame(x[1:minR,]); names(y)=orig.names; return(y)})
		warning("Objects pruned to the length of the smallest.")
	}
	C=sapply(list.obj, ncol)
	if(length(unique(C))!=1) stop("Cannot process objects; column lengths do not match.")
	c=unique(C)
	if(c>1) {
		M=lapply(1:length(list.obj), function(x) mm=match(names(list.obj[[x]]), orig.names))
		for(mm in 2:length(list.obj)) {
			list.obj[[mm]]=list.obj[[mm]][,M[[mm]]]
		}
	}
	r=nrow(list.obj[[1]])
	indices=lapply(1:n, function(x) seq(x, r*n, by=n))
	
	out.array=array(dim=c(r*n, c))
	for(nn in 1:n){
		out.array[indices[[nn]],]=as.matrix(list.obj[[nn]])
	}
	
	out.array=data.frame(out.array)
	if(!is.null(orig.names)) names(out.array)=orig.names else names(out.array)=paste("X",1:ncol(out.array),sep="")
	return(out.array)
}



#intercalates samples from multiple independent Markov chains (generated by rjmcmc.bm())
#author: JM EASTMAN 2010

pool.rjmcmcsamples <-
function(base.dirs, lab="combined"){
	outdir=paste(lab,"combined.rjmcmc",sep=".")
	if(!file.exists(outdir)) dir.create(outdir)
	
# estimated parameters
	samples=lapply(base.dirs, function(x) {load(paste(x, dir(x, pattern="posteriorsamples.rda"), sep="/")); return(posteriorsamples)})
	nn=unique(unlist(lapply(samples, names)))
	posteriorsamples=list()
	for(i in nn) {
		res.sub=intercalate.samples(lapply(1:length(samples), function(x) samples[[x]][[i]]))
		posteriorsamples[[which(nn==i)]]=res.sub
	}
	names(posteriorsamples)=nn
	save(posteriorsamples, file=paste(outdir, paste(lab,"posteriorsamples.rda",sep="."), sep="/"))
	
# logfile
	
	write.table(intercalate.samples(lapply(base.dirs, function(x) {y=read.table(paste(x, dir(x, pattern="rjmcmc.log"), sep="/"), header=TRUE); return(y)})), paste(outdir, paste(lab,"rjmcmc.log",sep="."), sep="/"), quote=FALSE, row.names=FALSE)
}

#general phylogentic utility wrapping geiger:::treedata for checking data consistency
#author: JM EASTMAN 2010

prepare.data <-
function(phy, data, SE) {
	td <- treedata(phy, data, sort = TRUE)	
	if(any(SE!=0)) {
		if(!is.null(names(SE))) {
			se=rep(0,length(td$phy$tip.label))
			names(se)=td$phy$tip.label
			ss.match=match(names(SE), names(se))
			if(any(is.na(ss.match))) warning(paste(names(SE[is.na(ss.match)]), "not found in the dataset", sep=" "))
			se[match(names(SE[!is.na(ss.match)]),names(se))]=SE[!is.na(ss.match)]
			SE=se
		} else {
			if(name.check(phy,data)=="OK" & length(data)==length(SE)) {
				names(SE)=td$phy$tip.label
				warning("ordering of values in SE assumed to be in perfect correspondence with phy$tip.label")
			} else {
				stop("SE must be a named vector of measurement error")
			}
		}
	} else {
		SE=rep(0,length(td$phy$tip.label))
		names(SE)=td$phy$tip.label
	}
	
	return(list(ape.tre=td$phy, orig.dat=td$data[,1], SE=SE))
}



