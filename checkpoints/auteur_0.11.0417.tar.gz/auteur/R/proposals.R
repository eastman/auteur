#rjmcmc proposal mechanism: proposal mechanism for traversing model complexity (by one parameter at a time)
#author: JM EASTMAN 2010

splitormerge <-
function(cur.delta, cur.values, phy, node.des, lambda=lambda, logspace=TRUE, internal.only=FALSE) { 
	bb=cur.delta
	vv=cur.values
	names(vv)<-names(bb)<-phy$edge[,2]
	new.bb=choose.one(bb, phy=phy, internal.only)
	new.vv=vv
	
	s=names(new.bb[bb!=new.bb])
	all.shifts=as.numeric(names(bb[bb>0]))
	all.D=node.des[[which(names(node.des)==s)]]
	if(length(all.D)!=0) {
		untouchable=unlist(lapply(all.shifts[all.shifts>s], function(x)node.des[[which(names(node.des)==x)]]))
		remain.unchanged=union(all.shifts, untouchable)
	} else {
		untouchable=NULL
		remain.unchanged=list()
	}
	
	marker=match(s, names(new.vv))
	nn=length(vv)
	K=sum(bb)
	N=Ntip(phy)
	
	ncat=sum(bb)
	cur.vv=as.numeric(vv[marker])
	ca.vv=length(which(vv==cur.vv))
	
	if(sum(new.bb)>sum(bb)) {			# add transition: SPLIT
		decision="split"
		n.desc=sum(!all.D%in%remain.unchanged)+1
		n.split=sum(vv==cur.vv)-n.desc
		if(!logspace) {
			u=splitvalue(cur.vv=cur.vv, n.desc=n.desc, n.split=n.split, factor=lambda) 
		} else {
			u=splitrate(cur.vv=cur.vv, n.desc=n.desc, n.split=n.split, factor=lambda)
		}
		nr.split=u$nr.split
		nr.desc=u$nr.desc
		new.vv[vv==cur.vv]=nr.split
		if(length(remain.unchanged)==0) {	# assign new value to all descendants
			new.vv[match(all.D,names(new.vv))] = nr.desc
		} else {							# assign new value to all 'open' descendants 
			new.vv[match(all.D[!(all.D%in%remain.unchanged)],names(new.vv))] = nr.desc
		}
		new.vv[match(s, names(new.vv))]=nr.desc
		lnHastingsRatio = log((K+1)/(2*N-2-K)) ### from Drummond and Suchard 2010: where N is tips, K is number of local parms in tree
		lnPriorRatio = log(ptpois(K+1,lambda,nn)/ptpois(K,lambda,nn))
		
	} else {							# drop transition: MERGE
		decision="merge"
		anc = get.ancestor.of.node(s, phy)
		if(!is.root(anc, phy)) {			# base new rate on ancestral rate of selected branch
			anc.vv=as.numeric(vv[match(anc,names(vv))])
			na.vv=length(which(vv==anc.vv))
			nr=(anc.vv*na.vv+cur.vv*ca.vv)/(ca.vv+na.vv)
			new.vv[vv==cur.vv | vv==anc.vv]=nr
		} else {							# if ancestor of selected node is root, base new rate on sister node
			sister.tmp=get.desc.of.node(anc,phy)
			sister=sister.tmp[sister.tmp!=s]
			sis.vv=as.numeric(vv[match(sister,names(vv))])
			ns.vv=length(which(vv==sis.vv))
			nr=(sis.vv*ns.vv+cur.vv*ca.vv)/(ca.vv+ns.vv)
			new.vv[vv==cur.vv | vv==sis.vv]=nr			
		}
		lnHastingsRatio = log((2*N-2-K+1)/K) ### from Drummond and Suchard 2010: where N is tips, K is number of local parms in tree
		lnPriorRatio = log(ptpois(K-1,lambda,nn)/ptpois(K,lambda,nn))
		
	}
	
	return(list(new.delta=new.bb, new.values=new.vv, lnHastingsRatio=lnHastingsRatio, lnPriorRatio=lnPriorRatio, decision=decision))
}


#general phylogenetic utility for selecting one element of a list of values, each of which can be associated with the edges of a phylogeny (phy$edge[,2])
#author: JM EASTMAN 2011

choose.one <-
function(cur.delta, phy, internal.only=FALSE)
# updated 02.26.2011 to weight by branch length (rather than equal weight for each edge)
{
	edge.prob=0.75
	e=phy$edge.length
	ee=cumsum(e/sum(e))
	bb=cur.delta
	if(internal.only) {
		names(bb)=phy$edge[,2]
		while(1) {
			if(runif(1)<edge.prob) {
				s=min(which(runif(1)<ee))
			} else {
				s=sample(1:length(bb),1)
			}
			if(as.numeric(names(bb[s]))>Ntip(phy)) break()
		}
	} else {
		if(runif(1)<edge.prob) {
			s=min(which(runif(1)<ee))
		} else {
			s=sample(1:length(bb),1)
		}
	}
	bb[s]=1-bb[s]
	bb
}


#rjmcmc proposal mechanism: split a rate into two while maintaining the mean
#author: JM EASTMAN 2010

splitrate <-
function(cur.vv, n.desc, n.split, factor=log(2)){
	dev=cur.vv-exp(log(cur.vv)+runif(1, -factor, factor))
	nr.desc=cur.vv+dev/n.desc
	nr.split=cur.vv-dev/n.split
	return(list(nr.desc=nr.desc, nr.split=nr.split))
}


#rjmcmc proposal mechanism: split a value into two while maintaining the mean
#author: JM EASTMAN 2010

splitvalue <-
function(cur.vv, n.desc, n.split, factor=log(2)){
	dev=cur.vv-adjustvalue(cur.vv, factor)
	nr.desc=cur.vv + dev/n.desc
	nr.split=cur.vv - dev/n.split
	return(list(nr.desc=nr.desc, nr.split=nr.split))
}


#rjmcmc proposal mechanism for updating lineage-specific relative rates (i.e., a subvector swap)
#author: JM EASTMAN 2010

tune.rate <-
function(rates, jumpsize) {
	ss=sample(rates, 1)
	ww=which(rates==ss)
	nn=adjustrate(ss,jumpsize)
	rates[ww]=nn
	return(rates)
}


#rjmcmc proposal mechanism for updating lineage-specific relative values (i.e., a subvector swap)
#author: JM EASTMAN 2010

tune.value <-
function(values, jumpsize) {
	ss=sample(values, 1)
	ww=which(values==ss)
	nn=adjustvalue(ss,jumpsize)
	values[ww]=nn
	return(values)
}


#scales VCV matrix of phylogeny by relative evolutionary rates under Brownian motion
#author: JM EASTMAN 2010

updatevcv <-
function(ape.tre, new.rates) {
	n=ape.tre
	n$edge.length=n$edge.length*new.rates
	vv=vmat(n)
	return(vv)
}



#rjmcmc proposal mechanism: scale a value given a proposal width ('jumpsize')
#author: JM EASTMAN 2010

adjustvalue <-
function(value, jumpsize) {
# mod 10.20.2010 JM Eastman
	vv=value
	if(runif(1)<0.95 | length(unique(vv))==1) {
		rch <- runif(1, min = -jumpsize, max = jumpsize)
		return(vv[]+rch)
	} else {
		return((vv-mean(vv))*runif(1,min=-jumpsize, max=jumpsize)+mean(vv))
	}
}


#rjmcmc proposal mechanism: scale a rate (limited to only positive values) given a proposal width ('jumpsize')
#author: JM EASTMAN 2010

adjustrate <-
function(rate, jumpsize) {
# mod 10.20.2010 JM Eastman
	vv=rate
	v=log(vv)
	rch <- runif(1, min = -jumpsize, max = jumpsize)
	v=exp(v[]+rch)
	v
}