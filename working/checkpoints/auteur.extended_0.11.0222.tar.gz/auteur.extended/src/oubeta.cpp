#include <Rcpp.h>
#include <vector>

/* C++ | R INTERFACE; main function */
RcppExport SEXP oubeta (SEXP PHYLO) 
{
	/* 
	 * TIMES: array form of VCV matrix (under Brownian motion): split times for pairs of species 
	 * ALPHA: herein, alpha is expected given as alpha^2
	 * SIGMA: herein, sigma is expected given as sigma^2
	 * TIPS: number of species
	 */
	
	try {
		Rcpp::List phylo(PHYLO);
		Rcpp::List ancestors = phylo["ancestors"];
		std::vector<double> regimes =  phylo["regimes"];
		std::vector<double> optima = phylo["optima"];
		int ntip = Rcpp::as<int> ( phylo["tips"] );
		
		int t, np, r, a, k, nreg=optima.size();
		std::vector< std::vector<int> > beta;
		
		for(t=0; t<ntip; t++) {
			std::vector<int> anc=ancestors[t];
			np=anc.size();
			std::vector<int> tbeta;
			tbeta.assign(np*nreg, 0);
			for(r=0; r<np; r++) {
				for(k=0; k<nreg; k++){
					if(regimes.at( anc.at(r)-1 )==optima.at(k))
					{
						tbeta.at(r+k*np)=1;
					}
				}
				
			}
			beta.push_back( tbeta );
			std::vector<int>().swap(anc);
			std::vector<int>().swap(tbeta);
		}
		/* PREPARE OUTPUT FOR R */
		return Rcpp::List::create(Rcpp::Named("beta", beta ));
		
	} catch( std::exception &ex ) {		
		forward_exception_to_r( ex );
    } catch(...) { 
		::Rf_error( "c++ exception (unknown reason)" ); 
    }
    return R_NilValue; 
}

