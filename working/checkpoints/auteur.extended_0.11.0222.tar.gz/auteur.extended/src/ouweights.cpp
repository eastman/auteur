#include <Rcpp.h>
#include <vector>

/* internal C++ */
void process_epochs ( std::vector<double> const &epochs, 
					  double const &alphasq, 
					  std::vector<double> &y) 
{
	int i, np = epochs.size();
	double t;
	
	for (i = 0; i < np; i++) {
		t = epochs[0]-epochs[i];
		y.push_back( exp(-alphasq*t) );
	}
	for (i = 0; i < np-1; i++) {
		y[i] -= y[i+1];
	}
}


/* C++ | R INTERFACE; main function */
RcppExport SEXP ouweights (
							  SEXP EPOCHS, 
							  SEXP BETA, 
							  SEXP ALPHA, 
							  SEXP TIPS, 
							  SEXP NREG) 
{
	/* 
	 * EPOCHS: list branching times for each segment from tip to root [T=t1>t2>...>troot=0] 
	 * BETA: a binary list ancestors [tip to root] signifying the selective regime in which the ancestral epoch resides
	 * ALPHA: herein, alpha is expected given as alpha^2
	 * TIPS: number of species
	 * REGIMES: number of distinct selective regimes in the tree
	 */
			
	try {
		Rcpp::List epochs(EPOCHS);
		Rcpp::List beta(BETA);
		double alphasq = Rcpp::as<double> (ALPHA);
		int ntip = Rcpp::as<int> (TIPS);
		int nreg = Rcpp::as<int> (NREG);
		
		int t, r, q;
		int segments;
		std::vector<double> y;
		std::vector<double> W;
		W.assign(ntip*nreg,0);

		for(t=0; t<ntip; t++) {
			std::vector<double> curEpochs=epochs[t];
			std::vector<double> curBeta=beta[t];
			segments=curEpochs.size();
			y.reserve(segments);
			process_epochs(curEpochs, alphasq, y);
			for(r=0; r<nreg; r++) {
				for(q=0; q<segments; q++) {
					W[t+r*ntip] += y[q]*curBeta[q+r*segments];
				}
			}
			std::vector<double>().swap(y);
			std::vector<double>().swap(curEpochs);
			std::vector<double>().swap(curBeta);
		}
		
		/* PREPARE OUTPUT FOR R */
		return Rcpp::List::create(Rcpp::Named("weights", W));

	} catch( std::exception &ex ) {		
		forward_exception_to_r( ex );
    } catch(...) { 
		::Rf_error( "c++ exception (unknown reason)" ); 
    }
    return R_NilValue; 
}

