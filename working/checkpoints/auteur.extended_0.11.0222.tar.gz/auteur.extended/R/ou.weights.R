ou.weights <- function(phy, epochs, beta, alpha){
# the list of epochs will always remain the same (calculate once)
# the list of Betas (branch paintings) will change, however!
	out <- .Call("ouweights",	
			EPOCHS=get.epochs(phy),
			BETA=beta$arr.beta,
			ALPHA=as.double(alpha^2), 
			TIPS=as.integer(Ntip(phy)),
			REGIMES=as.integer(length(beta$theta)), 
			PACKAGE = "auteur.extended")
	return(matrix(out$weights,ncol=length(beta$theta)))
} 

		
