ape.to.ouchtree<-function (tree, scale = FALSE) 
{
	branch.lengths = tree$edge.length
    if (!inherits(tree, "phylo")) 
	stop(sQuote("tree"), " must be of class ", sQuote("phylo"))
    nnodes <- nrow(tree$edge) + 1
    n.term <- length(tree$tip.label)
    n.int <- nnodes - n.term
    tmp <- matrix(NA, nnodes, 2)
    tmp[-1, 1:2] <- tree$edge
    tmp[1, 2] <- nnodes + 1
    bl <- c(0, branch.lengths)
	bl.ape=bl
	names(bl.ape)=c("root", tree$edge[,2])
    reord <- order(-tmp[, 2])
    bl <- bl[reord]
	bl.ouch <- bl.ape[reord]
    tmp <- tmp[reord, ]
    node <- seq(nnodes)
    ancestor <- rep(NA, nnodes)
    for (n in 2:nnodes) {
        anc <- which(tmp[, 2] == tmp[n, 1])
        if (length(anc) > 1) 
		stop("invalid tree")
        if (length(anc) > 0) {
            ancestor[n] <- node[anc]
        }
        else {
            ancestor[n] <- node[1]
        }
    }
    if (is.null(tree$node.label)) 
	tree$node.label <- rep("", n.int)
    species <- rev(c(tree$tip.label, tree$node.label[-1], tree$node.label[1]))
    times <- rep(NA, nnodes)
    for (n in 1:nnodes) times[n] <- ouch:::branch.height(node, ancestor, bl, n)
    if (is.logical(scale)) {
        if (is.na(scale)) 
		stop("if ", sQuote("scale"), " is logical, it must be either true or false")
        if (scale) 
		times <- times/max(times)
    }
    else if (is.numeric(scale)) {
        times <- times/abs(scale)
    }
    else {
        stop(sQuote("scale"), " must be either logical or numeric")
    }
    return(list(ouch.tre=ouchtree(nodes = node, ancestors = ancestor, times = times, labels = species), ape.ordered=bl.ouch))
}