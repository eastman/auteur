get.beta.OLD<-function (phy, object) 
{
# needs to be tip to root ordered
# object: has 'anc', 'des', 'time', and 'regimes'
	if(!all(c("anc","des","time","regimes")%in%names(object)))stop("Cannot decipher supplied 'object'.")
	tt = Ntip(phy)
	ur = sort(unique(regimes<-as.numeric(object$regimes)))
    nreg = length(ur)
	sorted.regimes=regimes[order(object$des)]
    beta = vector(mode = "list", length = tt)
	ancestors=lapply(1:Ntip(phy), function(x) c(x,rev(sort(get.ancestors.of.node(x,phy)))))
    for (i in 1:tt) {
        p <- ancestors[[i]]
        np <- length(p)
		beta[[i]] <- matrix(0, nrow = np, ncol = nreg)
		ar=sapply(p, function(x) which(ur==sorted.regimes[x]))
		for (rr in 1:nrow(beta[[i]])) {
			beta[[i]][rr,ar[rr]]=1
		}
    }
	names(beta)=phy$tip.label
	theta=ur
    return(list(beta=beta,theta=theta,arr.beta=lapply(beta, c)))
}

get.beta<-function (phy, object, ancestors) 
{
# needs to be tip to root ordered
# object: has 'anc', 'des', 'time', and 'regimes'
# ancestors: a list including the tip and all ancestors back to the root (in that order)
##		- e.g., ' ancestors=lapply(1:Ntip(phy), function(x) c(x,rev(sort(get.ancestors.of.node(x,phy))))) '
##		- the order in the list is expected to be 1:Ntip(phy) 
	
	if(!all(c("anc","des","time","regimes")%in%names(object)))stop("Cannot decipher supplied 'object'.")
	tt = Ntip(phy)
	object=object[order(object$des),]
	ur = sort(unique(as.numeric(object$regimes)))
    nreg = length(ur)
	
    beta = vector(mode = "list", length = tt)
	
	out <- .Call("oubeta",	
				 PHYLO=list(
						beta=beta,
						ancestors=ancestors,
						regimes=as.double(object$regimes),
						optima=as.double(ur),
						tips=as.integer(tt)),
				 PACKAGE = "auteur.extended")
	
    
    return(out$beta)
}