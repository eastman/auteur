get.regimes<-function(phy, regimes, ancestors)	
{
	names(regimes)=c(Ntip(phy)+1, phy$edge[,2])
	r=lapply(ancestors, function(x) unname(regimes[match(x,names(regimes))]))
	return(r)
	
}


