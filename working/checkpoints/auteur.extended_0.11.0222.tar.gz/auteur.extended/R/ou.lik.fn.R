ou.lik.fn <- function(rate, alpha, regimes, theta, ouch.dat, ouch.tre, ape.to.ouch.order, SE) { # from OUCH 2.7-1:::hansen()
# mod 11.17.2010 JM Eastman; checked -- returns very similar if tested against fitted values from hansen()
	ouch.dat$regimes=as.factor(regimes[c(1,ape.to.ouch.order+1)])
	alpha.ouch=as.matrix(alpha^2)
	n <- length(which(!is.na(ouch.dat['trait'])))	
	beta=ouch:::regime.spec(ouch.tre, ouch.dat['regimes']) 
	theta=as.numeric(levels(ouch:::sets.of.regimes(ouch.tre,ouch.dat['regimes'])$regimes))
	dat=ouch.dat$trait[n:nrow(ouch.dat)]
	names(dat)=ouch.dat$labels[n:nrow(ouch.dat)]
	ev <- eigen(alpha.ouch,symmetric=TRUE)
	w <- .Call(ouch:::ouch_weights,object=ouch.tre,lambda=ev$values,S=ev$vectors,beta=beta) 
	v <- .Call(ouch:::ouch_covar,object=ouch.tre,lambda=ev$values,S=ev$vectors,sigma.sq=rate)
	y <- matrix(theta,ncol=1)
	e <- w%*%y-dat
	dim(y) <- dim(y)[1]
	dim(e) <- n
	q <- e%*%solve(v,e)
	det.v <- determinant(v,logarithm=TRUE)
	dev <- n*log(2*pi)+as.numeric(det.v$modulus)+q[1,1]
	print(theta); print(ouch.dat); print(ouch.tre); print(beta)
	w=data.frame(w)
	row.names(w)=ouch.tre@nodelabels[ouch.tre@term]
	list(
		 theta=theta,
		 weight=w,
		 vcov=v,
		 resids=e,
		 lnL=-0.5*dev,
		 beta=beta
		 )
}
